MELKAMU GIZAT AGRICULTURE WEBSITE PACK

Files:
- index.html: updated bilingual website homepage with agricultural product categories and resource download links
- Farming_Guide_English_Amharic.pdf: bilingual farming guide
- Farming_Guide_English_Amharic.pptx: bilingual PowerPoint presentation

Upload steps on GitHub mobile:
1. Open repository: https://github.com/melikamugizat30-ctrl/melikamu-gizat
2. Upload index.html and both resource files into the repository root (same level as index.html).
3. If GitHub asks whether to replace index.html, confirm replacement.
4. Commit the changes to the main branch.
5. Wait a few minutes, then open https://melikamugizat30-ctrl.github.io/melikamu-gizat/
6. The PDF and PowerPoint download buttons should work when the two files are in the same repository root.

Notes:
- Product categories are informational examples only; no affiliate links or live prices have been added.
- To earn commissions, join affiliate programs available to you, then add approved affiliate URLs to the product cards.
- The farming guide is educational information, not a substitute for local extension or veterinary advice.
